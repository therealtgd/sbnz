package com.ftn.sbnz.backward.model;

public class BackwardModelApplication {

	public static void main(String[] args) {
		System.out.println( "Hello World!" );
	}

}
