mvn clean -f "./pom.xml" && mvn install -f "./pom.xml"
