package com.ftn.sbnz.kjar;

public class KjarApplication {

	public static void main(String[] args) {
		System.out.println("Hello from kjar!");
	}

}
